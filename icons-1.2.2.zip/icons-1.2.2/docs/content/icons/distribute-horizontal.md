---
title: Distribute horizontal
categories:
  - Graphics
tags:
  - space
  - align
---
