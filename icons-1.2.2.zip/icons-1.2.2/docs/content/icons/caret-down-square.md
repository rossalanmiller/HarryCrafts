---
title: Caret down square
layout: icon
categories:
  - Carets
tags:
  - caret
  - arrow
  - triangle
---
