---
title: Cone striped
categories:
  - Real world
tags:
  - construction
  - warning
  - safety
---
