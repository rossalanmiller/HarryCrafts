---
title: Diamond fill
categories:
  - Shapes
tags:
  - shape
---
