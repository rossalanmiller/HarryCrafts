---
title: Aspect ratio
categories:
  - Media
tags:
  - size
  - resize
  - crop
  - dimensions
---
